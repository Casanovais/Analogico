gds read {/data/02/up202208591/Analogico2/results/handoff-4071/design/layout.gds}
load CMIRROR
select top cell
drc on
drc style drc(full)
drc check
drc catchup
puts "DRC_COUNT=[drc list count total]"
puts "DRC_DETAILS=[drc listall why]"
drc off
extract all
ext2spice lvs
ext2spice subcircuit top on
ext2spice -o {/data/02/up202208591/Analogico2/results/handoff-4071/design/extracted.spice}
ext2spice cthresh 0
ext2spice -o {/data/02/up202208591/Analogico2/results/handoff-4071/design/extracted_capacitance.spice}
quit -noprompt
