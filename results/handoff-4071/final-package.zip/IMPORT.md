# SKY130 current-mirror handoff

Top cell: CMIRROR. Technology: SKY130A. Pin binding is by the SPICE
subcircuit declaration; extracted pin order may differ from schematic order.

Use evidence/layout.gds for stream import and evidence/schematic.spice as
the reference netlist. GDS contains polygons and labels; it does not recreate
editable PCells, a native schematic, or connectivity-aware layout metadata.
Attach the matching SKY130 technology library and its official layer map.
Do not map these geometries to another process without regeneration.

For Cadence Virtuoso, use the installed release's XStream In interface with
CMIRROR as top cell and a new destination library attached to the SKY130
technology. For Synopsys Custom Compiler, confirm the installed release's
GDS import procedure and technology mapping with the local CAD setup.
No commercial EDA installation was used to validate this package.
Re-run DRC/LVS and extracted simulation in the receiving flow.

qualification.json records the open-flow review gate and unresolved production
requirements. manifest.json hashes every packaged file except itself; these
hashes detect changes, but are not a signature or a foundry approval.
